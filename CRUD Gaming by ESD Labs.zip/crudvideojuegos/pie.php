<!DOCTYPE html>
<html lang="es">



<footer class="px-2 py-2 fixed-bottom bg-dark">
        <span class="text-muted">CRUD Gaming 2.0 by
            <a class="text-white" href="https://twitter.com/dev_edus">ESD Labs</a>
            &nbsp;|&nbsp;
            <a target="_blank" class="text-white" href="https://github.com/esdlabs-tech">
                Mi perfil de GitHub
            </a>
        </span>
</footer>
</body>
</html>
